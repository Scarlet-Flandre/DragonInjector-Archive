# DragonInjector-Firmware

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)
<a href="https://discord.gg/ez2HCgK"><img src="https://discordapp.com/api/guilds/488214231540301826/embed.png" alt="Discord Server" /></a>

Firmware source and releases for the DragonInjector project.

## Usage
This readme is under constuction

## Credits
* __MatinatorX__: - For Creating the DragonInjector
