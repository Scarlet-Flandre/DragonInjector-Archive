/* Licensed under GNU GPL V3
Written by Adran
Version 2.1.6
*/

/* Requirements */
const Discord = require('discord.js');

// Embed code
const embed = new Discord.RichEmbed()
  .setColor('#3A95A6')
  .setTitle('Dragonbot Presents the DragonFAQ')
  .setURL('https://dragoninjector.com/')
  .setAuthor('Dragonbot', 'https://media.discordapp.net/attachments/488214232203264001/651205690773340199/image0.png', 'https://github.com/dragoninjector-project/DragonBot')
  .setDescription('To help you better understand the range of Dragon Products')
  .setThumbnail('https://media.discordapp.net/attachments/516367045189959681/543270641646698528/DI_BADGE1.png')
  .addField('For the DragonInjector FAQ', 'Use `?difaq`')
  .addField('For the DragonKicker FAQ','Use `?dkfaq`')
  .addField('For the DragonMMC FAQ','Use `?dmmcfaq`')
  .addField('What about something that isn\'t? covered by the FAQ\'s?','Feel free to message in the discord server')
  //.addBlankField()
  .setImage('https://media.discordapp.net/attachments/516367045189959681/543270649901088778/DI_BANNER2.png')
  .setTimestamp()
  .setFooter('DragonInjector.com', 'https://media.discordapp.net/attachments/488214232203264001/651205690773340199/image0.png');
module.exports = (embed);
