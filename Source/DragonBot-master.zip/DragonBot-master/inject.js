/* Licensed under GNU GPL V3
Written by Adran
Version 2.1.6
*/

const Discord = require('discord.js');
const tools = new Discord.RichEmbed()
 .setColor('#3A95A6')
  .setTitle('Dragonbot Presents "How do I Payload?"')
  .setURL('https://github.com/dragoninjector-project/')
  .setAuthor('Dragonbot', 'https://media.discordapp.net/attachments/488214232203264001/651205690773340199/image0.png', 'https://github.com/dragoninjector-project/DragonBot')
  .setDescription('Helping you place your payloads in the right place.')
  .setThumbnail('https://media.discordapp.net/attachments/516367045189959681/543270641646698528/DI_BADGE1.png')
  .addField('How do I put a payload on the DragonInjector?', 'DI ships in single-payload mode and boots SD:/dragonboot/x.bin,\n x.bin can be the name of any payload you choose e.g hekate.bin. Short press button does nothing.')
  .addField('What about Multi-Payload?','To use multi-payload, plug DI into something, and while red LED flashing quickly, hold down button until long red flash. You are now in multi-payload.\n Put your payloads in a subfolder e.g SD:/dragonboot/02, SD:/dragonboot/03')
  .addField('How to Change Multi-Payload?','To switch payloads, short press button. Red LED will long-flash the number of the selected slot. Example, 3 long flashes will boot /dragonboot/03/x.bin.')
  //.addBlankField()
  .setImage('https://media.discordapp.net/attachments/516367045189959681/543270649901088778/DI_BANNER2.png')
  .setTimestamp()
  .setFooter('DragonInjector.com', 'https://media.discordapp.net/attachments/488214232203264001/651205690773340199/image0.png');
module.exports = (tools);