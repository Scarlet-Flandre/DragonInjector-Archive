/* Licensed under GNU GPL V3
Written by Adran
Version 2.1.6
*/

/* Requirements */
const Discord = require('discord.js');

// Embed code
const embed = new Discord.RichEmbed()
  .setColor('#3A95A6')
  .setTitle('Dragonbot Presents the DragonInjector FAQ')
  .setURL('https://dragoninjector.com/')
  .setAuthor('Dragonbot', 'https://media.discordapp.net/attachments/488214232203264001/651205690773340199/image0.png', 'https://github.com/dragoninjector-project/DragonBot')
  .setDescription('To help you better understand the DragonInjector')
  .setThumbnail('https://media.discordapp.net/attachments/516367045189959681/543270641646698528/DI_BADGE1.png')
  .addField('What is DragonInjector?','DragonInjector is a Switch payload injector in the form factor of a game cartridge, so it can easily be stored inside your Switch.')
  .addField('Where can I buy the DragonInjector?', 'You can purchase the DragonInjector from the [DragonInjector Store](https://www.dragoninjector.com) right now!!!')
  .addField('What is the current version?','The current DragonInjector version is 20, which is under development and will be out soon.')
  .addField('How much does it cost?','The DragonInjector costs $30USD + Postage and Handling')
  .addField('How is it powered?','The DragonInjector is powered by a user-replaceable CR1612 battery')
  .addField('How many injections of a single battery?','Over 3000 injections! Testers and myself are actually getting over 4000 injections per CR1612 in a lot of cases.')
  .addField('What about those game card pins then? What do they do?','They\'re there for aesthetic purposes and to protect the pins in the gamecard slot from damage and wear.')
 // .addBlankField()
  .addField('Where can I find out more?','You can find out more in the Discord \nor on the [website](https://www.dragoninjector.com)')
  .addField('The DragonInjector Sourcecode is availible for free!!', '[Dragoninjector Sourcecode](https://github.com/dragoninjector-project/)')
  .setImage('https://media.discordapp.net/attachments/516367045189959681/543270649901088778/DI_BANNER2.png')
  .setTimestamp()
  .setFooter('DragonInjector.com', 'https://media.discordapp.net/attachments/488214232203264001/651205690773340199/image0.png');
module.exports = (embed);
