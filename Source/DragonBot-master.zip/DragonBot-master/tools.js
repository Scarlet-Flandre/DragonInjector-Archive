/* Licensed under GNU GPL V3
Written by Adran
Version 2.1.6
*/

const Discord = require('discord.js');
const tools = new Discord.RichEmbed()
 .setColor('#3A95A6')
  .setTitle('Dragonbot Presents the DragonTools')
  .setURL('https://github.com/dragoninjector-project/')
  .setAuthor('Dragonbot', 'https://media.discordapp.net/attachments/488214232203264001/651205690773340199/image0.png', 'https://github.com/dragoninjector-project/DragonBot')
  .setDescription('Tools used for the DragonInjector')
  .setThumbnail('https://media.discordapp.net/attachments/516367045189959681/543270641646698528/DI_BADGE1.png')
  .addField('DragonInjector Update Tool', 'The DragonInjector Update tool is an easy way to update your DragonInjector.\n [Latest Release](https://github.com/dragoninjector-project/DragonInjector-UpdateTool/releases)')
  .addField('DragonInjector Bootloader','The DragonInjector Bootloader can be found [on this github](https://github.com/dragoninjector-project/DragonInjector-Bootloader/releases)')
  .addField('DragonInjector Firmware','The DragonInjector Firmware can be found [on this github](https://github.com/dragoninjector-project/DragonInjector-Firmware/releases)')
  .addField('Where can I find out more?','You can find out more here in the Discord \nor on the [website](https://www.dragoninjector.com)')
  .addField('The DragonInjector Sourcecode is availible for free!!', '[Dragoninjector Sourcecode](https://github.com/dragoninjector-project/)')
  //.addBlankField()
  .setImage('https://media.discordapp.net/attachments/516367045189959681/543270649901088778/DI_BANNER2.png')
  .setTimestamp()
  .setFooter('DragonInjector.com', 'https://media.discordapp.net/attachments/488214232203264001/651205690773340199/image0.png');
module.exports = (tools);