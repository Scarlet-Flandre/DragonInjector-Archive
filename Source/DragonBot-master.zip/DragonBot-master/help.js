/* Licensed under GNU GPL V3
Written by Adran
Version 2.1.6
*/

/* Requirements */
const Discord = require('discord.js');

// Embed code
const embed = new Discord.RichEmbed()
  .setColor('#3A95A6')
  .setTitle('Dragonbot Help')
  .setURL('https://dragoninjector.com/')
  .setAuthor('Dragonbot', 'https://media.discordapp.net/attachments/488214232203264001/651205690773340199/image0.png', 'https://github.com/dragoninjector-project/DragonBot')
  .setDescription('A list of all the DragonBot commands')
  .setThumbnail('https://media.discordapp.net/attachments/516367045189959681/543270641646698528/DI_BADGE1.png')
  .addField('?faq', '**- This command links to the FAQ\'s embed**')
  .addField('?tools','**- This command links to the tools embed**')
  .addField('?credits','**- This command links to the credits embed**')
  .addField('?help','**- Links to this embed**') 
  .addField('?docs','**- Links to the documentation embed**') 
  //.addBlankField()
  .setImage('https://media.discordapp.net/attachments/516367045189959681/543270649901088778/DI_BANNER2.png')
  .setTimestamp()
  .setFooter('DragonInjector.com', 'https://media.discordapp.net/attachments/488214232203264001/651205690773340199/image0.png');
module.exports = (embed);
