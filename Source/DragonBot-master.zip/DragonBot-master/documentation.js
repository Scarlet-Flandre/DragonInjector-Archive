/* Licensed under GNU GPL V3
Written by Adran
Version 2.1.6
*/

const Discord = require('discord.js');
const docs = new Discord.RichEmbed()
 .setColor('#3A95A6')
  .setTitle('Dragonbot Presents the Documentation')
  .setURL('https://github.com/dragoninjector-project/')
  .setAuthor('Dragonbot', 'https://media.discordapp.net/attachments/488214232203264001/651205690773340199/image0.png', 'https://github.com/dragoninjector-project/DragonBot')
  .setDescription('Draconic Mods Documentation')
  .setThumbnail('https://media.discordapp.net/attachments/516367045189959681/543270641646698528/DI_BADGE1.png')
  .addField('DragonInjector Configuration Options', 'This Document contains information on the Configuration Options. [DragonInjector Options](https://github.com/dragoninjector-project/Documentation/blob/master/DragonInjector/Configuring_Options.md)')
  //.addBlankField()
  .setImage('https://media.discordapp.net/attachments/516367045189959681/543270649901088778/DI_BANNER2.png')
  .setTimestamp()
  .setFooter('DragonInjector.com', 'https://media.discordapp.net/attachments/488214232203264001/651205690773340199/image0.png');
module.exports = (docs);