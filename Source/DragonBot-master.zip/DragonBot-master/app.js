/* Licensed under GNU GPL V3
Written by Adran and Dev\Null
Version 2.1.6
*/

/* Requirements */
const Discord = require('discord.js');
const client = new Discord.Client();
const token = require('./settings.json').token;

/* Modules Section */ 
const faq = require('./faq.js')
const tools = require('./tools.js')
const help = require('./help.js')
const credit = require('./credits.js')
const difaq = require('./difaq.js')
const dkfaq = require('./dkfaq.js')
const demmcfaq = require('./dmmcfaq.js')
const inject = require('./inject.js')
const docs = require('./documentation.js')

/* Loggin the bot in and setting its activity */
client.on('ready',() => {
    console.log(`Logged in as ${client.user.tag}!`);
    client.user.setActivity("?help & the Dragon's Horde", {type: "Watching"})
});

/* Set the bot to reply to DM commands */
client.on('message', message => {
     if (message.author.bot) 
        return;

    if (message.channel.type == 'dm') {
    if (message.content == ("?help")){
        message.reply(help);
    
    } else if(message.content == ("?faq")){
        message.reply(faq);
    
    } else if(message.content == ("?difaq")){
        message.reply(difaq);
    
    } else if(message.content == ("?dkfaq")){
        message.reply(dkfaq);
    
    } else if(message.content == ("?dmmcfaq")){
        message.reply(dmmcfaq);
    
    } else if(message.content == ("?tools")){
        message.reply(tools);  
    
    } else if(message.content == ("?credits")){
        message.reply(credit);

    } else if(message.content == ("?docs")){
        message.reply(docs);
    
    } else if 
    (message.reply("Please enter `?help` for a list of commands."));

}});

/* Set the bot to reply to normals server messages*/
client.on('message', message => {
    if (message.author.bot) return;
    if (message.channel.type !== "text") { 
        return;
    }
//this is here so anyone can trigger the commands
if(message.content == ("?faq")){
    message.react('651624619920588820');
    message.author.send(faq);

} else if(message.content == ("?difaq")){
    message.react('651624619920588820');
    message.author.send(difaq);

} else if(message.content == ("?dkfaq")){
    message.react('651624619920588820');
    message.author.send(dkfaq);

} else if(message.content == ("?dmmcfaq")){
    message.react('651624619920588820');
    message.author.send(dmmcfaq);

} else if(message.content == ("?tools")){
    message.react('651624619920588820');
    message.author.send(tools);

} else if(message.content == ("?help")){
    message.react('651624619920588820');
    message.author.send(help);

} else if(message.content == ("?credits")){
    message.react('651624619920588820');
    message.author.send(credit);

} else if(message.content == ("?docs")){
    message.react('651624619920588820');
    message.author.send(docs);
}

if (message.content === '?rave') {
        message.author.send(`<@${message.author.id}>, IT'S RAVE TIME!`, {files: ['https://media1.tenor.com/images/e19a05faf32c511572acd08a38bebdd6/tenor.gif']});
    }

    //Ignores users if they have one of the following roles for the regex
if (! message.member || message.member.roles.find('name', 'Creator') || message.member.roles.find('name', 'The Fuzz') || message.member.roles.find('name', 'Supporter')|| message.member.roles.find('name', 'Certified Madlad')) {
        return;
    }
//Sets regex constant for phrase(s) and replies
const preorder = message.content.match(new RegExp (/^(?=.*\b(dragon ?injector|di)\b)(?=.*\b(preorder|pre-order)\b).*$/i));
const buy = message.content.match(new RegExp(/^(?=.*\b(dragon ?injector|di)\b)(?=.*\b(order|buy|purchase|sale)\b).*$/i));
const cost = message.content.match(new RegExp(/^(?=.*\b(dragon ?injector|di)\b)(?=.*\b(cost|price)\b).*$/i));
const commands = message.content.match(new RegExp (/^(?=.*\b(dragon ?bot|db|di|bot|dragonbot)\b)(?=.*\b(help|halp)\b).*$/i));
const payload = message.content.match(new RegExp (/^(?=.*\b(how|help|inject)\b)(?=.*\b(payload|payloads)\b).*$/i));
     if(preorder) {  
    message.react('651624619920588820')
    message.author.send(`<@${message.author.id}>, Sorry MatinatorX doesn't believe in preorders but you can now buy it from https://www.dragoninjector.com.`);
}   
    if(buy) {  
    message.react('651624619920588820')
    message.author.send(`<@${message.author.id}>, The DragonInjector v20 is currently *NOT* available to buy. When it is available you can order it from https://www.dragoninjector.com.`);
}
    if(cost) {  
    message.react('651624619920588820')
    message.author.send(`<@${message.author.id}>, Cost will be $30 USD plus postage and handling. For more see <#489199851171610649>`);
}
    if(commands) {
    message.react('651624619920588820')  
    message.author.send(help);
}
    if(payload) {
    message.react('651624619920588820')  
    message.author.send(inject);
}
 });

client.login(token);