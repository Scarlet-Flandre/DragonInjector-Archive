/* Licensed under GNU GPL V3
Written by Adran
Version 2.1.6
*/

/* Requirements */
const Discord = require('discord.js');

// Embed code
const embed = new Discord.RichEmbed()
  .setColor('#3A95A6')
  .setTitle('Dragonbot Credits')
  .setURL('https://dragoninjector.com/')
  .setAuthor('Dragonbot', 'https://media.discordapp.net/attachments/488214232203264001/651205690773340199/image0.png', 'https://github.com/dragoninjector-project/DragonBot')
  .setDescription('A list of credits')
  .setThumbnail('https://media.discordapp.net/attachments/516367045189959681/543270641646698528/DI_BADGE1.png')
  .addField('MatinatorX', '- For creating the DragonInjector')
  .addField('Stuck Pixel','- For helping with bootloader and firmware')
  .addField('Jerome','- For the DragonInjector firmware update tool')
  .addField('Adran','- For the Dragonbot') 
  .addField('Kevhawk','- For the Ticketbot')
  .addField('The Testers','- For testing the DragonInjector')
  .addField('Everyone Else','- For supporting the dragoninjector-project')
  //.addBlankField()
  .setImage('https://media.discordapp.net/attachments/516367045189959681/543270649901088778/DI_BANNER2.png')
  .setTimestamp()
  .setFooter('DragonInjector.com', 'https://media.discordapp.net/attachments/488214232203264001/651205690773340199/image0.png');
module.exports = (embed);
