/* Licensed under GNU GPL V3
Written by Adran
Version 2.1.6
*/

/* Requirements */
const Discord = require('discord.js');

// Embed code
const embed = new Discord.RichEmbed()
  .setColor('#3A95A6')
  .setTitle('Dragonbot Presents the DragonFAQ')
  .setURL('https://dragoninjector.com/')
  .setAuthor('Dragonbot', 'https://media.discordapp.net/attachments/488214232203264001/651205690773340199/image0.png', 'https://github.com/dragoninjector-project/DragonBot')
  .setDescription('To help you better understand the range of Dragon Products')
  .setThumbnail('https://media.discordapp.net/attachments/516367045189959681/543270641646698528/DI_BADGE1.png')
  .addField('What is the DragonKicker?','The DragonKicker is a multi-MicroSD, replacement kickstand solution for the Switch.')
  .addField('Is this under development?','The DragonKicker project has been retired. See the DragonMMC for more.')
  .addField('Where can I get the DragonKicker?','The DragonKicker is availible for free to 3d print your own from [here](https://github.com/dragoninjector-project/DragonInjector-HardwareSources/tree/master/Models/Old_Kicker). The switched version is under development')
  .addField('Where can I find out more?','You can find out more in the Discord \nor on the [website](https://www.dragoninjector.com)')
  .addField('The DragonInjector Sourcecode is availible for free!!', '[Dragoninjector Sourcecode](https://github.com/dragoninjector-project/)')
  //.addBlankField()
  .setImage('https://media.discordapp.net/attachments/516367045189959681/543270649901088778/DI_BANNER2.png')
  .setTimestamp()
  .setFooter('DragonInjector.com', 'https://media.discordapp.net/attachments/488214232203264001/651205690773340199/image0.png');
module.exports = (embed);

