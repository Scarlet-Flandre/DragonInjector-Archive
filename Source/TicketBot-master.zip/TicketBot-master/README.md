# TicketBot

[![License: GPL v3](https://img.shields.io/badge/License-GPL%20v3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0.html)
<a href="https://discord.gg/ez2HCgK"><img src="https://discordapp.com/api/guilds/488214231540301826/embed.png" alt="Discord Server" /></a>

## TicketBot for the Dragon Injector Discord Server

## How it works
This bot is programmed to create a new help channel limited to the user, mods and MatinatorX when a user has an issue with their DragonInjector. Detailed usage can be found in the #create-ticket channel in the discord server.

## Credits 
* __MatinatorX__: For the DragonInjector
* __Kevhawk__: Programming and hosting the Ticketbot
