# NoUSB

[![License: GPL v2](https://img.shields.io/badge/License-GPL%20v2-blue.svg)](https://www.gnu.org/licenses/gpl-2.0.html)
<a href="https://discord.gg/ez2HCgK"><img src="https://discordapp.com/api/guilds/488214231540301826/embed.png" alt="Discord Server" /></a>

## What is NoUSB?

NoUSB is a small, simple payload that disables the USB controller on the Switch and displays a splash and a message to the user.

## How does it work?

NoUSB sets a bit to indicate that the Switch is "waking up from sleep" in the "power management controller" (PMC), sets up for an exploit and then performs a reboot (which preserves state in the PMC). On reboot, the "wake from sleep" codepath is taken, and then exploited using the exploit we set up for earlier. The reboot disables the USB controller and the exploit allows the splash and message to be shown to the user.

## Credits

* __devkitPro:__ for the [devkitARM](https://devkitpro.org/) toolchain.
* __naehrwert__ and __st4rk:__ for the original [hekate](https://github.com/nwert/hekate) project.
* __CTCaer:__ for the continuation of the [hekate](https://github.com/CTCaer/hekate) project.
* __Guillem96:__ for the [argon-nx](https://github.com/Guillem96/argon-nx) project.
* __MatinatorX:__ for the [DragonInjector](https://github.com/dragoninjector-project/DragonInjector-Project) project
* __pixel-stuck:__ developer of NoUSB
* All the testers who helped iron out bugs!
